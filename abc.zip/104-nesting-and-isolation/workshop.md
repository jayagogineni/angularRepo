# Workshop for this step

Goals:

* Understand which templates have access to which class fields.

-----

1. Add a property to the outer component.
2. Try binding to it in the outer component template.
3. Try binding to it in the inner component template.
