# Workshop for this step

* Convert the rest of the static HTML controls on the right to Angular
  reactive controls.
* Subscribe to the valuechanges of the controls you created in an
  earlier step.
* Emit the resulting value to the parent component.
* Bind the value into the statGraph component and display it.

The options are not being used to perform any calculations at this
point. Rather this step exercises subscribing and data binding to user input.
