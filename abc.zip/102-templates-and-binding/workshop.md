# Workshop for this step

Goals:

* Get comfortable accessing data in component classes from templates.

-----

1. Add a few more fields in the component class.
2. Add data for the new the fields.
3. Bind to them in the template.
