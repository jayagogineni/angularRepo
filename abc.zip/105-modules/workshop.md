# Workshop for this step

* Make a new module
* Make a new component
* Add the new component to the declarations of the new module
* Add the new module to the imports in app.module.ts
* Reference the new component in the template of nesting.ts
