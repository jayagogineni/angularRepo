import { Component } from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: './abc-page.html'
})
export class AbcPageComponent {
}
