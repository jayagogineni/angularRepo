export class GreetingCalculator {
  greeting() {
    return 'Hello, World';
  }
}
