# Workshop for this step

* Create a new service. This service should contain a function that
  will return the video list as a JavaScript object.
* Inject the service into the appropriate component.
* Call the newly-created function to obtain the data.
* Bind to the video list as appropriate.

```
ng generate service videoList
```
