import { Component } from '@angular/core';

@Component({
  selector: 'do-example',
  templateUrl: './do.component.html',
  moduleId: __moduleName
})
export class DoComponent{
  
}