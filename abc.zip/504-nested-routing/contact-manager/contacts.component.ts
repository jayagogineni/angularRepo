import {Component} from '@angular/core';

@Component({
  moduleId: __moduleName,
  templateUrl: './contacts.component.html'
})
export class ContactsComponent {

}
