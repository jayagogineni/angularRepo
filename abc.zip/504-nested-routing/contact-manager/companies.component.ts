import {Component} from '@angular/core';

@Component({
  moduleId: __moduleName,
  templateUrl: './companies.component.html'
})
export class CompaniesComponent {

}
