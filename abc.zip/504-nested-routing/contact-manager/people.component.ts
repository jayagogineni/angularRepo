import {Component} from '@angular/core';

@Component({
  moduleId: __moduleName,
  templateUrl: './people.component.html'
})
export class PeopleComponent {

}
