import './simple.spec';
import './hello.service.spec';
import './score/score.component.spec';
