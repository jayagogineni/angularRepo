describe('My first test suite', () => {
  it('should perform a simple test', () => {
    expect(true).toBe(true);
  });
});
