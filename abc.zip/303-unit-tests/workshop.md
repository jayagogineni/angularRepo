# Workshop for this step

(Your instructor may skip the workshop for this step, or may
demonstrate similar ideas in an Angular CLI application then ask you
to add a simple unit test to your application.)

* Add another function to the hello service.
* Add another unit test to the hello service spec to test it.

