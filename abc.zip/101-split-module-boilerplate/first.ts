import { Component } from '@angular/core';

@Component({
  selector: 'abc-page',
  template: '<h1>My First TypeScript Angular App</h1>'
})
export class FirstComponent { }
