# Workshop for this step

Instructor sometimes skip this workshop for time; as it is not
necessary for the functioning but only for a better appearance.

* Find the CSS for a component (either what you wrote, or what we may
  provide), currently in the page-level CSS file.
* Move that CSS to a component-level CSS file.
