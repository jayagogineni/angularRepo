# Workshop for this step

* Add the sample data (demo-data/videoManagerData.json) to the
  videoListComponent.
* For now, it is OK to define this as a component property and assign the
  data directly. In future steps we will demonstrate how to retrieve
  this using HTTP.
* Modify the video list template to display each video using `*ngFor`.
