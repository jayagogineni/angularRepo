import { Component } from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: './page.component.html'
})
export class PageComponent { }
