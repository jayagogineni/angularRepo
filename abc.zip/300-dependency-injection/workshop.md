# Workshop for this step

* Inject Title into video list component.
* Set the title programmatically whenever a new video is selected.
