import {Component} from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: './page.html'
})
export class PageComponent {
}
