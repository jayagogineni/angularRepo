import {Component} from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: './app.component.html'
})
export class MessagesComponent {

}
