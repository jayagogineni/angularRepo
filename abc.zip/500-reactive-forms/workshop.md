# Workshop for this step

* Convert your standalone reactive controls (in a component which has
  multiple controls) to work as a reactive form instead.
