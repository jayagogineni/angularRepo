import { Component } from '@angular/core';

@Component({
  selector: 'some-name',
  moduleId: __moduleName,
  templateUrl: './name.component.html'
})
export class NameComponent {
}
