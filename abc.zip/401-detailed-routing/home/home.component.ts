import { Component } from '@angular/core';

@Component({
  selector: 'home-component',
  moduleId: __moduleName,
  templateUrl: './home.component.html'
})
export class HomeComponent {
}
