# Workshop for this step

* Edit some of the sample data in your application to include a field
  with "dangerous" HTML.
* Name this field in a way that makes it clear the HTML came from a
  trusted backend system, not from arbitrary user input.
* Use sanitization controls to enable this HTML displaying unsafely in
  your application.
