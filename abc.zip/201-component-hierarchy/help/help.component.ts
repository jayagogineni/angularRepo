import { Component } from '@angular/core';

@Component({
  selector: 'help-screen',
  moduleId: __moduleName,
  templateUrl: './help.component.html'
})
export class HelpScreenComponent { }
