import { Component } from '@angular/core';

@Component({
  selector: 'app-email',
  moduleId: __moduleName,
  templateUrl: './email-container.component.html'
})
export class EmailComponent { }
