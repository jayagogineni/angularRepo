import { Component } from '@angular/core';

@Component({
  selector: 'message-header',
  moduleId: __moduleName,
  templateUrl: './message-header.component.html'
})
export class MessageHeaderComponent { }
