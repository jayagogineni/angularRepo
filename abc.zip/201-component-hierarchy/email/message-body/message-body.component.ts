import { Component } from '@angular/core';

@Component({
  selector: 'message-body',
  moduleId: __moduleName,
  templateUrl: './message-body.component.html'
})
export class MessageBodyComponent { }
