import { Component } from '@angular/core';

@Component({
  selector: 'folder-list',
  moduleId: __moduleName,
  templateUrl: './folder-list.component.html'
})
export class FolderListComponent { }
