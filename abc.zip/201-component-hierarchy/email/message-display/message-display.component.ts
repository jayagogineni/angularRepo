import { Component } from '@angular/core';

@Component({
  selector: 'message-display',
  moduleId: __moduleName,
  templateUrl: './message-display.component.html'
})
export class MessageDisplayComponent { }
