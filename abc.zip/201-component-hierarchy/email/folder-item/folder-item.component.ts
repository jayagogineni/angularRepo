import { Component } from '@angular/core';

@Component({
  selector: 'folder-item',
  moduleId: __moduleName,
  templateUrl: './folder-item.component.html'
})
export class FolderItemComponent { }
