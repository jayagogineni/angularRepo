import { Headers } from '@angular/http';

export const jsonRequestHeaders = {
  headers: new Headers({
    'Accept': 'application/json'
  })
};
