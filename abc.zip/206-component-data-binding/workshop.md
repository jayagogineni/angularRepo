# Workshop for this step

* Make a component that represents a single video in the list.
* Update your *ngFor to use that component instead of plain HTML.
* Utilize component data binding to supply the data for each video entry.
* Verify that clicking a video still results in visually identifying
  the selected video.
