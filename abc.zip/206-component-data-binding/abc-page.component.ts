import { Component } from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: './abc-page.component.html'
})
export class AbcPageComponent { }
