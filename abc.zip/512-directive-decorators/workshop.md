# Workshop for this step

1. Make your own variation of the directives here, which animates or
   modified the behavior of an element.
