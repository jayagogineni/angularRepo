import { Component } from '@angular/core';

@Component({
  selector: 'abc-page',
  templateUrl: 'directives.html'
})
export class DirectivesComponent {

}
